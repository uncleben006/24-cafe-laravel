
-- --------------------------------------------------------

--
-- 資料表結構 `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `authority` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的匯出資料 `users`
--

INSERT INTO `users` (`id`, `authority`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Ben', 'uncleben006@gmail.com', '$2y$10$UTqt76hj0caaxtC9i92TPeCc.f8WoA7sj/nF5bTlahCV9qQjFNOM.', 'AIYl9YxPlpk8aFBBpFi5cmeJ2oIQIs8tN9PfkNdtwQyRWDRsXr147mdTZePa', '2018-11-04 12:20:12', '2018-11-04 12:20:12'),
(5, 0, 'Jeff', 'jeff@gmail.com', '$2y$10$oGF4qgqS5xUl7dBp/yHbeOC9QlCGYWh///zCDB7n2S4nu6TqBjTd.', 'hD2lP88iI08tBeyMzSzcX08cpVvGg4elwE67h2cH4LI5z3tnorJQg3mxPVuh', '2018-11-10 16:28:17', '2018-11-10 16:28:17'),
(6, 0, 'Oscar', 'oscar@gmail.com', '$2y$10$GTL3vf20o/YtqO7APNwwbefs.YGmOCJ8Sn8R0Sv2iVAj1iZmzEKza', 'YwhAcpbaHPjc3NMpEHPYAB3F9AZY4Kt0JMEE5rZ39BlLhDbSQykVW2DCXIOE', '2018-11-10 16:29:26', '2018-11-10 16:29:26'),
(7, 0, 'Victor', 'victor@gmail.com', '$2y$10$Y7iVoshEqdXzGt1hn692h.a4i/RrJiHr9Hc99JrbBGbQEg4xtMj8e', 'Qk8mElc28ZTukfAGwNZ5cqCKlxs6On5igwTXb73Faa5c5xyjRyxE7X9Nixnl', '2018-11-10 16:29:35', '2018-11-10 16:29:35'),
(8, 0, '24 Caf\'e', '24cafe@gmail.com', '$2y$10$5HX5cdZ1qL7YUr/nC45DUOel1ITiDBa5K0eeha8eXkLfwGbvWk/W6', 'F836qAenbckluN9LMWqf8SXVL7Pg73Wj4KbXwquiFLVZXqUAUTlOlDHMsASp', '2018-11-11 13:12:29', '2018-11-11 13:12:29');
