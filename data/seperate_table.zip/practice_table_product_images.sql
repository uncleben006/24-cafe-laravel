
-- --------------------------------------------------------

--
-- 資料表結構 `product_images`
--

CREATE TABLE `product_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的匯出資料 `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `class`, `filename`, `created_at`, `updated_at`) VALUES
(1, 1, 'racket', '57d0e5a5-591b-46bf-ad90-6d0659f13107.jpg', '2018-11-04 12:28:16', '2018-11-04 12:28:16'),
(2, 1, 'racket', '204b913e-8254-4569-bbbf-40b51f18f972.jpg', '2018-11-04 12:28:16', '2018-11-04 12:28:16'),
(3, 1, 'racket', '02103489-4e98-405b-93f0-53dc2157c2e2.jpg', '2018-11-04 12:28:16', '2018-11-04 12:28:16'),
(4, 2, 'bag', 'PG8801 JC.jpg', '2018-11-08 14:19:34', '2018-11-08 14:19:34'),
(5, 3, 'racket', '57d0e5a5-591b-46bf-ad90-6d0659f13107.jpg', '2018-11-08 14:20:18', '2018-11-08 14:20:18'),
(6, 3, 'racket', '204b913e-8254-4569-bbbf-40b51f18f972.jpg', '2018-11-08 14:20:18', '2018-11-08 14:20:18'),
(7, 3, 'racket', '02103489-4e98-405b-93f0-53dc2157c2e2.jpg', '2018-11-08 14:20:18', '2018-11-08 14:20:18');
