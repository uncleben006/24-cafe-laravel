
-- --------------------------------------------------------

--
-- 資料表結構 `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `introduction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `series` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rank` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的匯出資料 `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `class`, `introduction`, `detail`, `category`, `series`, `rank`, `brand`, `created_at`, `updated_at`) VALUES
(1, 'Durax 10', 5180, 'racket', '雙面式的設計，全面提升球員能力，達到進攻與防守兼具的效果', '正拍採用<b>盒式</b>設計增加整體穩定度，\r\n<br>反拍採用<b>破風</b>設計增加回球速度，\r\n<br>能夠全面提升球員能力，達到進攻與防守兼具的效果', '力量', '亮劍', '專業', 'Yonax', '2018-11-04 12:28:16', '2018-11-11 12:54:13'),
(2, 'PG8801 JC', 1000, 'bag', '好背實用的VICTOR藍色包包', '好背實用的VICTOR藍色包包', NULL, NULL, NULL, 'VICTOR', '2018-11-08 14:19:33', '2018-11-11 13:17:49'),
(3, 'MX-80', 3000, 'racket', '中桿硬，適合攻擊', '在經典高端拍MX-80的基礎上增加強芯填充技術，優化球拍操控性能，精准掌控每一個落點，盡享揮拍時優越手感。', '攻擊', '尖峰', '專業', 'VICTOR', '2018-11-08 14:20:18', '2018-11-11 13:33:27'),
(4, 'JS-10 C', 4900, 'racket', '低調墨色消光漆底，襯托細緻內斂塗裝，帶給消費者視覺和手感都與眾不凡的極致享受。', 'VICTOR兩大尖端材料「PYROFIL 三菱百洛碳素纖維」與「NANO FORTIFY 增韌奈米碳管」技術，搭載特殊小拍面及細中管設計，賦予JETSPEED S 10輕快銳利的紮實打感。低調墨色消光漆底，襯托細緻內斂塗裝，帶給消費者視覺和手感都與眾不凡的極致享受。', '速度', '極速系列', NULL, NULL, '2018-11-11 13:24:32', '2018-11-11 13:24:32'),
(5, 'SH-A960 DF', 2300, 'footwear', '紅色的鞋子', '紅色的鞋子', NULL, NULL, NULL, 'VICTOR', '2018-11-11 15:45:46', '2018-11-11 15:45:46'),
(6, 'SH-P9200-BA 藏青-珠光白', 2500, 'footwear', '青色的鞋子', '青色的鞋子', NULL, NULL, NULL, 'VICTOR', '2018-11-11 15:46:24', '2018-11-11 15:48:06'),
(7, 'P8510-CX 黑-亮金', 2100, 'footwear', '黑色的鞋子', '黑色的鞋子', NULL, NULL, NULL, 'VICTOR', '2018-11-11 15:46:52', '2018-11-11 15:51:08'),
(8, 'PG8801 MC', 1300, 'bag', '藍色包包', '藍色包包', NULL, NULL, NULL, 'VICTOR', '2018-11-11 15:52:02', '2018-11-11 15:52:02');
