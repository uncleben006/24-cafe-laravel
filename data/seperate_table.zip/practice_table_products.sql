
-- --------------------------------------------------------

--
-- 資料表結構 `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `series` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rank` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的匯出資料 `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `class`, `description`, `category`, `series`, `rank`, `brand`, `created_at`, `updated_at`) VALUES
(1, 'Durax 10', 3000, 'racket', '好打', '力量', '亮劍', '專業', 'Yonax', '2018-11-04 12:28:16', '2018-11-04 12:28:16'),
(2, 'PG8801 JC', 1000, 'bag', '好背實用', NULL, NULL, NULL, 'VICTOR', '2018-11-08 14:19:33', '2018-11-08 14:19:33'),
(3, 'Durax 10', 4500, 'racket', '很全面的一支球拍', '全面', '亮劍', '專業', 'Yonax', '2018-11-08 14:20:18', '2018-11-08 14:20:18');
