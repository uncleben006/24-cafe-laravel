
-- --------------------------------------------------------

--
-- 資料表結構 `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的匯出資料 `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_08_16_102701_create_post_table', 1),
(4, '2018_09_07_144529_create_chat_table', 1),
(5, '2018_09_07_150400_create_products_table', 1),
(6, '2018_09_07_150717_create_order_lists_table', 1),
(7, '2018_09_24_010421_create_product_images_table', 1),
(8, '2018_11_04_194510_create_filters_table', 1);
