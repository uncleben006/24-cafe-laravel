
-- --------------------------------------------------------

--
-- 資料表結構 `chat`
--

CREATE TABLE `chat` (
  `id` int(10) UNSIGNED NOT NULL,
  `author` int(11) NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的匯出資料 `chat`
--

INSERT INTO `chat` (`id`, `author`, `message`, `created_at`, `updated_at`) VALUES
(12, 1, '嗨嗨嗨', '2018-11-10 01:34:22', '2018-11-10 01:34:22'),
(13, 1, '妳好', '2018-11-10 01:34:24', '2018-11-10 01:34:24'),
(14, 1, '我覺得今天天氣不錯', '2018-11-10 01:34:31', '2018-11-10 01:34:31');
