
-- --------------------------------------------------------

--
-- 資料表結構 `filters`
--

CREATE TABLE `filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filter_class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filter_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的匯出資料 `filters`
--

INSERT INTO `filters` (`id`, `product_class`, `filter_class`, `filter_name`, `sequence`, `created_at`, `updated_at`) VALUES
(5, 'racket', 'series', '亮劍', 0, '2018-11-04 15:19:30', '2018-11-08 15:58:42'),
(7, 'footwear', 'category', '速度系列', 0, '2018-11-04 15:20:01', '2018-11-06 16:50:05'),
(9, 'racket', 'series', '極速系列', 1, '2018-11-08 16:57:33', '2018-11-08 16:57:33'),
(10, 'racket', 'series', '脈動系列', 2, '2018-11-08 16:57:47', '2018-11-08 16:57:47'),
(11, 'racket', 'category', '速度', 0, '2018-11-08 17:10:27', '2018-11-08 17:10:27'),
(12, 'racket', 'category', '進攻', 1, '2018-11-08 17:10:36', '2018-11-08 17:10:36'),
(13, 'racket', 'category', '全面', 3, '2018-11-08 17:10:44', '2018-11-08 17:11:01');
